# The quiz room

The course's quizzes as live rounds, with a leaderboard on the projector. One file of
Python 3.8 or later and nothing else: no packages, no internet.

## Start

```
python3 room.py
```

It prints three addresses:

| Address | Where it opens |
|---|---|
| `http://localhost:8080/host` | your controls, on this laptop only |
| `http://localhost:8080/board` | the projector |
| `http://<this laptop>:8080/` | where participants join; the board shows it with a QR code |

Participants need to be on the same network as the laptop. If the network keeps devices
apart, share your phone's hotspot and join everyone to it. On a Mac, allow the incoming
connection when the firewall asks. If the board shows the wrong address, pass the right one:
`python3 room.py --ip 10.0.0.5`. Another port: `--port 9000`.

## A round

1. Pick a round in the controls: one per page's quiz, and one per speed game.
2. **Open question**: the clock starts on every screen at once.
3. The question closes itself when the time is up or everyone has answered; **Show the answer**
   closes it early. The board shows the answer, how the room voted, and the fastest right answer.
4. **Show the leaderboard**, then **Next question**. After the last one, **The podium**.

A round stopped half way carries on from its first unasked question. A finished round can be
played again, and its points count again.

## Points

- A right answer: 500, and up to 500 more for speed. Each player's clock starts when the
  question reaches their screen, so a slow connection costs nothing.
- Each right answer in a row after the first: 50 more, up to 250.
- From the players list: **+500** for a passed done test, **+300** for work shown to the room.
- Badges: first right answer, three, five and ten in a row, fastest right answer, a perfect
  round, a passed done test, work shown to the room.

The board shows the top ten; everyone sees their own rank on their own screen.

## Keeping the scores

The scores are saved in `room-state.json` beside `room.py` after every change. Close the room
(Ctrl+C) at the end of a day and start it again the next morning to carry on with the same
leaderboard. `python3 room.py --fresh`, or **Start a new leaderboard** in the controls, starts
over. Names and answers never leave the laptop.

`questions.json` holds the questions and their answers in English and Arabic. It is read only
by `room.py`: no answer reaches a participant's screen before the reveal. Switch the room's
language in the controls.

---

## بالعربي

مسابقة مباشرة من أسئلة الدورة، والترتيب على شاشة القاعة. تحتاج Python 3.8 أو أحدث وبس.

1. شغّل `python3 room.py`، وافتح لوحة التحكم `http://localhost:8080/host` على جهازك، وشاشة العرض `/board` على البروجكتر.
2. المشاركون يدخلون من العنوان أو رمز QR اللي على الشاشة، وهم على نفس الشبكة. ولو الشبكة تفصل الأجهزة، شارك نقطة اتصال جوالك.
3. اختر الجولة، وافتح السؤال، واكشف الإجابة، واعرض الترتيب، وكمّل.
4. النقاط تنحفظ في `room-state.json`. سكّر المسابقة آخر اليوم وشغّلها بكرة، وتكمل من مكانك.
