# GASTAT house style for R: the colours, a chart theme and a table.
# Every document in this folder starts with source("R/gastat.R").

library(tidyverse)
library(tinytable)

gastat_colours <- c(
  indigo     = "#4137A8",
  green      = "#00B050",   # large shapes and lines
  green_text = "#00803A",   # text size
  blue       = "#2683C6",
  cyan       = "#1CADE4",
  teal       = "#27CED7",
  mint       = "#42BA97",
  dark       = "#2C2D3F",
  grey       = "#6B6C7A",
  line       = "#E6E7EC",
  soft       = "#F5F7FA"
)

# Charts use the Tajawal files in fonts/, not whatever the machine has installed,
# so a chart looks the same on every computer, offline included.
if (!"Tajawal" %in% c(systemfonts::system_fonts()$family, systemfonts::registry_fonts()$family)) {
  systemfonts::register_font(
    "Tajawal",
    plain = "fonts/Tajawal-Regular.ttf",
    bold = "fonts/Tajawal-Bold.ttf"
  )
}
knitr::opts_chunk$set(dev = "ragg_png", dpi = 200)

theme_gastat <- function(base_size = 12) {
  theme_minimal(base_size = base_size, base_family = "Tajawal") +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = gastat_colours[["line"]], linewidth = 0.3),
      axis.text = element_text(colour = gastat_colours[["grey"]]),
      axis.title = element_text(colour = gastat_colours[["grey"]]),
      plot.title = element_text(colour = gastat_colours[["dark"]], face = "bold",
                                size = rel(1.2), margin = margin(b = 4)),
      plot.subtitle = element_text(colour = gastat_colours[["grey"]], margin = margin(b = 10)),
      plot.caption = element_text(colour = gastat_colours[["grey"]], size = rel(0.75), hjust = 0),
      plot.title.position = "plot",
      plot.caption.position = "plot",
      legend.position = "top",
      legend.justification = "left",
      legend.title = element_blank()
    )
}

# The house table: bold header over an indigo rule, one decimal place, and the
# styles kept inside the page (portable), so it is styled with no internet too.
tt_gastat <- function(x, ...) {
  tt(x, ...) |>
    format_tt(digits = 1, num_fmt = "decimal", num_zero = TRUE) |>
    style_tt(i = 0, bold = TRUE, line = "b", line_color = gastat_colours[["indigo"]]) |>
    theme_html(portable = TRUE)
}

# "2025Q4" in the data, "2025 Q4" on the page
quarter_label <- function(q) str_replace(q, "Q", " Q")

# Under every chart and table built from the course data.
synthetic_note <- "Source: synthetic training data, not official GASTAT statistics."
