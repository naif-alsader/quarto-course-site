# GASTAT Quarto template

A folder you copy and start from: a regional bulletin and a briefing deck in the GASTAT
house style, from one R analysis. Everything it needs is inside, so it works offline.

| File | What it is |
|---|---|
| `report.qmd` | the bulletin: HTML, Word and PDF from one file, every number computed |
| `slides.qmd` | the briefing: the number, the key figures, the trend, the regions, the ask |
| `_brand.yml` | the house style as a file: GASTAT's colours, Tajawal, the logo |
| `R/gastat.R` | `theme_gastat()` for charts, `tt_gastat()` for tables, `gastat_colours` |
| `theme/` | the finishing touches: the indigo title block, cards, dividers |
| `gastat-reference.docx` | the Word styles |
| `fonts/`, `images/`, `data/` | the fonts, the logos, and synthetic example data |

## Start

1. Copy the whole folder and open it in Positron (Open Folder...).
2. Render the bulletin: `quarto render report.qmd`. Another region:
   `quarto render report.qmd -P region:Riyadh`.
3. Render the deck: `quarto render slides.qmd`.
4. Put your own data in `data/`, change the setup chunk, and write your own sentences.

Needs R with the tidyverse and tinytable, and Quarto 1.9 or later. The data are synthetic,
made for training: replace them before anything leaves the building.

## ابدأ من هنا

مجلد جاهز: نشرة للمنطقة وعرض للمدير بهوية الهيئة، من تحليل R واحد، ويشتغل بدون إنترنت.
انسخ المجلد كامل وافتحه في Positron، وولّد `report.qmd` و`slides.qmd`. لمنطقة ثانية:
`quarto render report.qmd -P region:Riyadh`. البيانات هنا مصطنعة للتدريب، فبدّلها ببياناتك
قبل ما يطلع أي شيء للنشر.
